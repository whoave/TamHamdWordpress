
    </div>
    <div class="temizle"></div>
  </div>    
  <div class="temizle"></div>


<div class="renkliCubuk"></div>
<div id="bitis">copyright 2018 zulkarneeyn</div>
<?php wp_footer();?>
</body>
</html>